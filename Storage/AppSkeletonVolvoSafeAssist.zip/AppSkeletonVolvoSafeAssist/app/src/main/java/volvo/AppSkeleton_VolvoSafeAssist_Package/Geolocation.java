package volvo.AppSkeleton_VolvoSafeAssist_Package;

import java.util.Vector;

/**
 * Created by Dara on 2017-12-02.
 */

public class Geolocation {
    private Vector mGpsLoc;


    public void get_loc(){

        //implement here

    }
}
