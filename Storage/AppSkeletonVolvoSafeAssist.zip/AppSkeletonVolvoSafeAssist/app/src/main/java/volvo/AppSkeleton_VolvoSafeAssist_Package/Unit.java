package volvo.AppSkeleton_VolvoSafeAssist_Package;

/**
 * Created by Dara on 2017-12-02.
 */

public class Unit {
    private Double mRadius;
    private String mIdentifier;


    public int login(){
        int loginSuccessful;

        //implement here


        return loginSuccessful;
    }

    public int alarm_listen(){
        int incommingAlarm;

        //implement here


        return incommingAlarm;
    }

}
