package volvo.AppSkeleton_VolvoSafeAssist_Package;

/**
 * Created by Dara on 2017-12-02.
 */

public class Alarm_data {
    public int mAlarmLevel;
    public float mDistance;
}
