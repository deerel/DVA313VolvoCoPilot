package volvo.AppSkeleton_VolvoSafeAssist_Package;

/**
 * Created by Dara on 2017-12-02.
 */

public class Controller {
    private Unit mUnit;
    private Geolocation mLoc;
    private Servercom mConn;

    public void loc_listener(){

        //implement here


    }

    public void display_alarm(){

        //implement here


    }

    public void display_notification(){

        //implement here


    }

    public void update_location(){

        //implement here


    }

    public void set_construction_site(){

        //implement here


    }

    public void edit_construction_site(){

        //implement here


    }

    public void delete_construction_site(){

        //implement here


    }

    private void id_device(){

        //inplement here


    }

}
