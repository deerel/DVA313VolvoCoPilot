package volvo.AppSkeleton_VolvoSafeAssist_Package;

/**
 * Created by Dara on 2017-12-02.
 */

//Note: Having Co-Pilot is not a qualified Java class name because of the -

public class CoPilot extends Unit{
    private Handheld_device mDriver;

    public void assoc_driver(Handheld_device driverId){

        //implement here


    }

    public void update_speed(){

        //implement here


    }

}
