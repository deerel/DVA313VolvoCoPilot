package volvo.AppSkeleton_VolvoSafeAssist_Package;

/**
 * Created by Dara on 2017-12-02.
 */

public class Handheld_device extends Unit{
    public int mAccessLevel;
}
