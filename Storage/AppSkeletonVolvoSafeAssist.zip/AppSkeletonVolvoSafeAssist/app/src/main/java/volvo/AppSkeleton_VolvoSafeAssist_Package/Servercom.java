package volvo.AppSkeleton_VolvoSafeAssist_Package;

/**
 * Created by Dara on 2017-12-02.
 */

public class Servercom {

    public void connect_db(){

        //implement here


    }

    public Alarm_data get_alert(){

        Alarm_data alarm = new Alarm_data();

        //implement here


        return alarm;
    }
}
